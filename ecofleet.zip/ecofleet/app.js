/* EcoFleet dashboard: route model, maps, fleet views and the driver companion.
   Demo data only. Cloud features (auth, live location, trip records, Excel export) live in firebase-service.js. */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);

  // ---- Route model constants (illustrative, not certified emissions factors) ----
  const BASE_KM = 46.9;            // diesel baseline route length
  const NEUTRAL_KM = 42.8;         // EV route length at default settings
  const DIESEL_KG_PER_KM = 0.75;   // light commercial diesel van, approx.
  const GRID_KG_PER_KWH = 0.71;    // Indian grid average, approx.
  const SAVINGS_RATIO = 0.72;      // share of the diesel baseline saved (analytics chart)
  const TRIP_SHARE = 0.2;          // share of the route covered by the driver-companion trip
  const BATTERY_KWH = 45;          // assumed pack size for EV-04
  const TRIP_START_BATTERY = 86;   // EV-04 battery at trip start (%)

  const state = { driverMode:false, playing:false, progress:0, timer:null, mapLayer:"eco", route:null, trip:null };
  const vehicles = [
    {id:"EV-04",name:"Volta Cargo",battery:86,cargo:72,status:"Delivering",eta:"12:42 PM",lat:13.0067,lng:80.2206},
    {id:"EV-07",name:"E-Cargo Mini",battery:38,cargo:45,status:"Charging",eta:"01:10 PM",lat:13.0108,lng:80.2150},
    {id:"EV-12",name:"Urban Electric",battery:64,cargo:91,status:"Delivering",eta:"12:58 PM",lat:13.0014,lng:80.2510},
    {id:"EV-03",name:"Volta Cargo",battery:22,cargo:30,status:"Idle",eta:"—",lat:13.0198,lng:80.2350}
  ];
  const places = {
    warehouse:{lat:13.0358,lng:80.2101,name:"Central Warehouse",type:"Warehouse"},
    stops:[
      {lat:13.0067,lng:80.2206,name:"Delivery stop · Alwarpet"},
      {lat:13.0014,lng:80.2510,name:"Delivery stop · Adyar"},
      {lat:13.0215,lng:80.2544,name:"Delivery stop · Thiruvanmiyur"},
      {lat:13.0460,lng:80.2310,name:"Delivery stop · Teynampet"}
    ],
    chargers:[
      {lat:13.0108,lng:80.2150,name:"Guindy EV charging hub"},
      {lat:13.0295,lng:80.2470,name:"Nandanam fast charger"}
    ]
  };
  let mainMap=null, driverMap=null, routeLine=null, driverRouteLine=null, driverVehicleMarker=null, toastTimer=null, chartResizeTimer=null;
  const routePoints = [[13.0358,80.2101],[13.029,80.214],[13.020,80.217],[13.013,80.222],[13.0067,80.2206],[13.003,80.232],[13.0014,80.2510],[13.011,80.255],[13.0215,80.2544]];
  const originalRoute = routePoints.map(p=>[...p]);
  let currentPath = routePoints;
  const round = (n, d) => Number(n.toFixed(d));

  function toast(message){
    const el=$("toast"); el.textContent=message; el.classList.add("show");
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2800);
  }
  function addActivity(title, detail, color="green-bg", icon="✓"){
    const list=$("activity-list");
    const item=document.createElement("div"); item.className="activity-item";
    item.innerHTML=`<span class="activity-icon ${color}">${icon}</span><div><b></b><p></p><small>Just now</small></div>`;
    item.querySelector("b").textContent=title;
    item.querySelector("p").textContent=detail;
    list.prepend(item);
    while(list.children.length>5) list.lastElementChild.remove();
  }
  function makeIcon(symbol,color,shape="circle"){
    return L.divIcon({className:"custom-map-icon",html:`<div style="width:29px;height:29px;display:grid;place-items:center;background:${color};color:#0c150b;border:2px solid #e5f6dc;border-radius:${shape==="square"?"8px":"50%"};box-shadow:0 2px 12px #0008;font-size:13px;font-weight:800">${symbol}</div>`,iconSize:[29,29],iconAnchor:[14,14],popupAnchor:[0,-13]});
  }
  function initMap(id, driver=false){
    const map=L.map(id,{zoomControl:true,scrollWheelZoom:false}).setView([13.021,80.231],12);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",{attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',subdomains:"abcd",maxZoom:19}).addTo(map);
    if(driver) return map;
    L.marker([places.warehouse.lat,places.warehouse.lng],{icon:makeIcon("W","#b6ff5c","square")}).addTo(map).bindPopup(`<b>${places.warehouse.name}</b><br>Primary dispatch hub`);
    places.stops.forEach((p,i)=>L.marker([p.lat,p.lng],{icon:makeIcon(String(i+1),"#ffc078")}).addTo(map).bindPopup(`<b>${p.name}</b><br>Delivery window: ${i+1}:00–${i+2}:00 PM`));
    places.chargers.forEach(p=>L.marker([p.lat,p.lng],{icon:makeIcon("ϟ","#b69cff","square")}).addTo(map).bindPopup(`<b>${p.name}</b><br>Public EV charging point`));
    routeLine=L.polyline(routePoints,{color:"#b6ff5c",weight:4,opacity:.88,dashArray:"8 7"}).addTo(map);
    vehicles.forEach((v,i)=>{
      const marker=L.marker([v.lat,v.lng],{icon:makeIcon("ϟ",i===0?"#75baff":"#b6ff5c")}).addTo(map);
      marker.bindPopup(`<b>${v.id} · ${v.name}</b><br>Battery: ${v.battery}%<br>Load: ${v.cargo}%<br>Status: ${v.status}`);
    });
    map.fitBounds(routeLine.getBounds().pad(.15));
    return map;
  }
  function updateMapRoute(){
    if(!routeLine||!mainMap)return;
    const p=Number($("payload").value),t=Number($("traffic").value),ev=Number($("ev-pref").value);
    const bend=(t-50)/5000, shift=(p-650)/60000;
    currentPath=originalRoute.map((pt,i)=>[pt[0]+(i%2?bend:-bend)*.2+(i>3?shift:-shift),pt[1]+(i%2?shift:-shift)+((100-ev)/10000)*(i%3-1)]);
    routeLine.setLatLngs(currentPath);
    routeLine.setStyle({color:ev>55?"#b6ff5c":"#75baff",dashArray:t>65?"4 8":null});
    mainMap.fitBounds(routeLine.getBounds().pad(.16),{animate:true,duration:.5});
    if(driverRouteLine)driverRouteLine.setLatLngs(currentPath);
  }
  function renderFleet(){
    $("fleet-body").innerHTML=vehicles.map(v=>{
      const cls=v.status.toLowerCase();
      return `<tr><td><div class="vehicle-name"><span class="vehicle-avatar">ϟ</span><span><b>${v.id}</b><small>${v.name}</small></span></div></td><td><div class="battery-cell"><div class="battery-top"><span>${v.battery}%</span></div><div class="battery-bar"><i class="${v.battery<30?"low":""}" style="width:${v.battery}%"></i></div></div></td><td>${v.cargo}%</td><td><span class="status-tag ${cls}">${v.status}</span></td><td>${v.eta}</td></tr>`;
    }).join("");
  }

  // Route model. Traffic avoidance trades a small detour for higher average speed.
  // Payload and elevation cost speed and energy. EV share sets how many kilometres run on electricity.
  // Defaults reproduce the 42.8 km / 1h 23m / 13.0 kWh / 22.1 kg CO₂ shown in the static markup.
  function routeModel(p,e,t,ev){
    const distance=Math.max(28, NEUTRAL_KM + 0.06*(t-60) + 0.02*(ev-80));
    const speed=Math.max(14, 28 + 0.06*t - 0.03*e - 0.004*Math.max(0,p-650));   // km/h
    const minutes=distance/speed*60;
    const kwhPerKm=0.245 + (p/1200)*0.07 + (e/100)*0.08;
    const energy=distance*kwhPerKm;
    const evShare=Math.min(1, 0.35 + 0.6*(ev/100));
    const evKm=distance*evShare, dieselKm=distance-evKm;
    const routeEmissions=dieselKm*DIESEL_KG_PER_KM + evKm*kwhPerKm*GRID_KG_PER_KWH;
    const carbon=Math.max(0, BASE_KM*DIESEL_KG_PER_KM - routeEmissions);
    return {distance, speed, minutes, kwhPerKm, energy, carbon, distanceChangePct:(distance-BASE_KM)/BASE_KM*100};
  }
  function formatMinutes(total){
    const m=Math.round(total);
    return Math.floor(m/60)+"h "+String(m%60).padStart(2,"0")+"m";
  }
  function calculate(){
    const p=Number($("payload").value),e=Number($("elevation").value),t=Number($("traffic").value),ev=Number($("ev-pref").value);
    $("payload-value").textContent=p+" kg";
    $("elevation-value").textContent=(e<35?"Low":e<70?"Moderate":"High")+" · "+e+"%";
    $("traffic-value").textContent=(t<35?"Low":t<70?"Balanced":"High")+" · "+t+"%";
    $("ev-pref-value").textContent=(ev<35?"Low":ev<70?"Medium":"High")+" · "+ev+"%";
    [$("payload"),$("elevation"),$("traffic"),$("ev-pref")].forEach(el=>el.style.setProperty("--range",((el.value-el.min)/(el.max-el.min)*100)+"%"));

    const r=routeModel(p,e,t,ev);
    state.route=r;
    state.trip={km:r.distance*TRIP_SHARE, minutes:r.distance*TRIP_SHARE/r.speed*60, kwh:r.distance*TRIP_SHARE*r.kwhPerKm, carbonKg:r.carbon*TRIP_SHARE};

    $("result-distance").textContent=r.distance.toFixed(1);
    $("result-time").textContent=formatMinutes(r.minutes);
    $("result-energy").textContent=r.energy.toFixed(1)+" kWh";
    $("result-carbon").textContent=r.carbon.toFixed(1)+" kg";
    $("distance-change").textContent=(r.distanceChangePct<0?"−":"+")+Math.abs(r.distanceChangePct).toFixed(1)+"% distance";
    $("route-distance").textContent=r.distance.toFixed(1)+" km";
    $("route-time").textContent=formatMinutes(r.minutes);
    $("route-carbon").textContent=r.carbon.toFixed(1)+" kg";
    const note=ev>70?"EV-first routing is prioritized. The system favors charging-ready electric vehicles and low-emission road segments.":t>70?"Traffic avoidance is prioritized. The suggested route is slightly longer but keeps average speed up and reduces stop-start energy use.":p>850?"Heavy payload detected. The estimate accounts for increased energy demand and favors a balanced route.":"Current settings balance EV preference, payload, terrain and traffic to reduce emissions without sacrificing delivery time.";
    $("optimizer-note").textContent=note;
    updateMapRoute(); drawChart(); renderDriverProgress();
  }
  function getDailyBaseline(days){
    return Array.from({length:days},(_,i)=>17+Math.abs(Math.sin(i*1.7+2))*12+Math.cos(i*.6)*4);
  }
  function drawChart(){
    const canvas=$("carbon-chart");if(!canvas)return;
    const rect=canvas.getBoundingClientRect();if(!rect.width||!rect.height)return;
    const dpr=window.devicePixelRatio||1;canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);
    const ctx=canvas.getContext("2d");ctx.setTransform(dpr,0,0,dpr,0,0);
    const w=rect.width,h=rect.height;ctx.clearRect(0,0,w,h);
    const days=Number($("chart-period").value),n=Math.min(days,14);
    const vals=getDailyBaseline(days).slice(0,n);
    const max=45, left=28, right=8, top=10, bottom=24, chartH=h-top-bottom, chartW=w-left-right, gap=chartW/n, barW=Math.min(15,gap*.48);
    ctx.font='9px "DM Sans", sans-serif';ctx.textAlign="right";ctx.fillStyle="#718177";
    [0,15,30,45].forEach(v=>{const y=top+chartH-(v/max)*chartH;ctx.strokeStyle="#263329";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(w-right,y);ctx.stroke();ctx.fillText(String(v),left-7,y+3)});
    vals.forEach((v,i)=>{const x=left+i*gap+gap/2;const bh=v/max*chartH;ctx.fillStyle="#3d4a40";ctx.beginPath();ctx.roundRect(x-barW/2,top+chartH-bh,barW,bh,3);ctx.fill();const greenH=bh*SAVINGS_RATIO;ctx.fillStyle="#b6ff5c";ctx.beginPath();ctx.roundRect(x-barW/2,top+chartH-greenH,barW,greenH,3);ctx.fill();if(n<=7||i%2===0){ctx.fillStyle="#7f9084";ctx.textAlign="center";ctx.fillText(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i%7],x,h-7)}});
    // The chart headline is CO₂ saved, which is the green share of each diesel-baseline bar.
    const saved=vals.reduce((a,b)=>a+b,0)*SAVINGS_RATIO;
    $("chart-total").innerHTML=saved.toFixed(1)+' <small>kg</small>';
  }
  function getDashboardSnapshot(){
    const r=state.route, days=Number($("chart-period").value);
    return {
      metrics:{co2AvoidedKg:$("co2-total").textContent, fuelCostSaved:$("fuel-total").textContent, fleetEfficiencyPct:$("efficiency-total").textContent, activeVehicles:"18 / 24"},
      route:{distanceKm:r.distance, travelTime:formatMinutes(r.minutes), energyKwh:r.energy, carbonKg:r.carbon, distanceVsDieselPct:r.distanceChangePct,
        settings:{payloadKg:Number($("payload").value), elevationPct:Number($("elevation").value), trafficPct:Number($("traffic").value), evPreferencePct:Number($("ev-pref").value)}},
      trip:{...state.trip},
      analytics:{days, savingsRatio:SAVINGS_RATIO, dailyBaselineKg:getDailyBaseline(days)},
      vehicles:vehicles.map(v=>({...v})),
      activity:[...$("activity-list").querySelectorAll(".activity-item")].map(el=>({
        title:el.querySelector("b")?.textContent||"", detail:el.querySelector("p")?.textContent||"", time:el.querySelector("small")?.textContent||""
      }))
    };
  }
  function optimize(){
    calculate(); toast("Eco-route recalculated using your current settings.");
    addActivity("Route recalculated", `New estimate: ${state.route.distance.toFixed(1)} km · ${state.route.carbon.toFixed(1)} kg CO₂ avoided`);
  }

  // ---- Driver companion ----
  function ensureDriverMap(){
    if(driverMap) return;
    driverMap=initMap("driver-map",true);
    driverRouteLine=L.polyline(currentPath,{color:"#b6ff5c",weight:5,opacity:.9}).addTo(driverMap);
    driverVehicleMarker=L.marker(currentPath[0],{icon:makeIcon("ϟ","#b6ff5c")}).addTo(driverMap).bindPopup("<b>EV-04</b><br>Demo vehicle position");
    driverMap.fitBounds(driverRouteLine.getBounds().pad(.2));
  }
  function setMode(driver){
    if(!driver) stopTrip(); // leaving the companion view pauses the simulation
    state.driverMode=driver;
    $("mode-toggle").setAttribute("aria-pressed",String(driver));
    $("mode-label").textContent=driver?"Fleet dashboard":"Driver mode";
    $("app-shell").classList.toggle("hidden",driver);
    $("driver-view").classList.toggle("active",driver);
    if(driver){
      ensureDriverMap(); renderDriverProgress();
      setTimeout(()=>{if(driverMap)driverMap.invalidateSize();},120);
    }else{
      setTimeout(()=>{if(mainMap)mainMap.invalidateSize();},120);
    }
  }
  function renderDriverProgress(){
    const trip=state.trip; if(!trip) return;
    const done=state.progress/100, remaining=1-done;
    $("driver-progress-text").textContent=Math.round(state.progress)+"%";
    $("driver-progress-bar").style.width=state.progress+"%";
    $("driver-distance").textContent=(trip.km*remaining).toFixed(1)+" km";
    $("driver-eta").textContent=Math.max(0,Math.ceil(trip.minutes*remaining))+" min";
    $("driver-battery").textContent=Math.round(TRIP_START_BATTERY-(trip.kwh/BATTERY_KWH)*100*done)+"%";
    $("driver-carbon").textContent=trip.carbonKg.toFixed(1)+" kg CO₂";
    if(driverRouteLine&&driverVehicleMarker){
      const pts=driverRouteLine.getLatLngs(), scaled=done*(pts.length-1), idx=Math.min(pts.length-2,Math.floor(scaled)), f=scaled-idx;
      const pos=L.latLng(pts[idx].lat+(pts[idx+1].lat-pts[idx].lat)*f, pts[idx].lng+(pts[idx+1].lng-pts[idx].lng)*f);
      driverVehicleMarker.setLatLng(pos); driverMap.panTo(pos,{animate:true,duration:.3});
    }
  }
  function setProgress(p){
    state.progress=Math.max(0,Math.min(100,p));
    renderDriverProgress();
    if(state.progress>=100) completeTrip();
  }
  function completeTrip(){
    stopTrip();
    const trip=state.trip;
    $("driver-play").textContent="✓ Trip completed";
    toast("Trip simulation completed. Great eco-driving!");
    addActivity("Trip completed", `EV-04 · ${trip.km.toFixed(1)} km · ${trip.carbonKg.toFixed(1)} kg CO₂ avoided`, "blue-bg", "⌖");
    document.dispatchEvent(new CustomEvent("ecofleet:trip-complete",{detail:{
      vehicleId:"EV-04", distanceKm:round(trip.km,2), energyKwh:round(trip.kwh,2), carbonKg:round(trip.carbonKg,2), durationMin:Math.round(trip.minutes)
    }}));
  }
  function startTrip(){
    if(state.playing)return;
    if(state.progress>=100)setProgress(0);
    state.playing=true;
    $("driver-play").textContent="Ⅱ Pause trip simulation";
    state.timer=setInterval(()=>setProgress(state.progress+1),500);
  }
  function stopTrip(){
    state.playing=false; clearInterval(state.timer); state.timer=null;
    const btn=$("driver-play");
    if(btn) btn.textContent = state.progress>=100 ? "✓ Trip completed" : state.progress>0 ? "▶ Resume trip simulation" : "▶ Start trip simulation";
  }

  function refreshDemo(){
    const carbon=(284.6+Math.random()*4-2).toFixed(1);$("co2-total").textContent=carbon;
    $("fuel-total").textContent="₹"+Math.round(8420+Math.random()*140-70).toLocaleString("en-IN");
    $("efficiency-total").textContent=(91.4+Math.random()*.8-.4).toFixed(1);
    vehicles.forEach(v=>{if(v.status==="Delivering")v.battery=Math.max(15,v.battery-(Math.random()<.6?1:0));});
    renderFleet();drawChart();toast("Demo telemetry refreshed.");
  }
  function wire(){
    $("mode-toggle").addEventListener("click",()=>setMode(!state.driverMode));
    $("back-dashboard").addEventListener("click",()=>setMode(false));
    ["payload","elevation","traffic","ev-pref"].forEach(id=>$(id).addEventListener("input",calculate));
    $("recalculate-btn").addEventListener("click",optimize);
    $("optimize-now").addEventListener("click",()=>{optimize();$("optimization").scrollIntoView({behavior:"smooth"});});
    $("refresh-btn").addEventListener("click",refreshDemo);
    $("export-btn").addEventListener("click",()=>{ if(window.EcoFleet.exportWorkbook) window.EcoFleet.exportWorkbook(); else toast("Export isn't available right now."); });
    $("chart-period").addEventListener("change",drawChart);
    $("driver-play").addEventListener("click",()=>state.playing?stopTrip():startTrip());
    $("driver-end").addEventListener("click",()=>{stopTrip();setProgress(0);setMode(false);toast("Trip simulation ended.");});
    $("map-recenter").addEventListener("click",()=>{ if(driverMap&&driverRouteLine) driverMap.fitBounds(driverRouteLine.getBounds().pad(.2)); });
    $("map-layer-btn").addEventListener("click",()=>{state.mapLayer=state.mapLayer==="eco"?"standard":"eco";$("map-layer-btn").textContent=state.mapLayer==="eco"?"Eco routes⌄":"Standard routes⌄";if(routeLine)routeLine.setStyle({color:state.mapLayer==="eco"?"#b6ff5c":"#75baff",dashArray:state.mapLayer==="eco"?"8 7":null});toast(state.mapLayer==="eco"?"Eco route layer enabled.":"Standard route layer enabled.");});
    document.querySelectorAll("[data-scroll]").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));btn.classList.add("active");const target=$(btn.dataset.scroll);if(target)target.scrollIntoView({behavior:"smooth"});$("breadcrumb-current").textContent=btn.textContent.trim();}));
    $("view-activity").addEventListener("click",()=>toast("Showing the latest simulated fleet events."));
    $("all-fleet").addEventListener("click",()=>toast("Demo fleet: 18 active, 6 on standby, 24 total vehicles."));
    window.addEventListener("resize",()=>{clearTimeout(chartResizeTimer);chartResizeTimer=setTimeout(drawChart,120);});
  }

  // Give the app shell an ID without coupling layout markup to JavaScript.
  $("app-shell") || document.querySelector(".app-shell").setAttribute("id","app-shell");

  // Public surface for firebase-service.js. exportWorkbook is attached there.
  window.EcoFleet = { toast, addActivity, getDashboardSnapshot, makeIcon, map:()=>mainMap, exportWorkbook:null };

  renderFleet(); wire();
  if(window.L){
    mainMap=initMap("map");
  }else{
    $("map").innerHTML='<div style="padding:35px;color:#a9b8ac;line-height:1.8">Map tiles need an internet connection. All other dashboard controls work offline.<br><small>Leaflet.js and Carto basemap are loaded from public CDNs.</small></div>';
  }
  calculate(); drawChart();
})();
