/* Firebase web config for EcoFleet.
   Replace the placeholder values with the config from:
   Firebase Console → Project settings → Your apps → Web app → SDK setup and configuration.
   These values identify your project and are not secrets. Access is enforced by firestore.rules. */
window.ECOFLEET_FIREBASE_CONFIG = {
  apiKey: "REPLACE_WITH_API_KEY",
  authDomain: "REPLACE_WITH_PROJECT_ID.firebaseapp.com",
  projectId: "REPLACE_WITH_PROJECT_ID",
  storageBucket: "REPLACE_WITH_PROJECT_ID.appspot.com",
  messagingSenderId: "REPLACE_WITH_SENDER_ID",
  appId: "REPLACE_WITH_APP_ID"
};
