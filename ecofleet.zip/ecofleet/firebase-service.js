/* EcoFleet cloud layer: Firebase Auth + Firestore, live visitor location, vehicle GPS markers,
   trip records and the Excel export. Loads after app.js.
   Without a configured firebase-config.js the dashboard stays in demo mode. */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const cfg = window.ECOFLEET_FIREBASE_CONFIG || {};
  const app = window.EcoFleet;
  const LOCATION_WRITE_MS = 15000;
  const isPlaceholder = (v) => !v || String(v).startsWith("REPLACE");
  const configured = typeof firebase !== "undefined" && !isPlaceholder(cfg.apiKey) && !isPlaceholder(cfg.projectId);

  let auth = null, db = null, user = null;
  let authMode = "signin";
  let watchId = null, lastWriteAt = 0, visitorMarker = null;
  let vehicleLayer = null, unsubscribeVehicles = null;

  const serverTime = () => firebase.firestore.FieldValue.serverTimestamp();
  const userRef = () => db.collection("users").doc(user.uid);
  const round = (n, d = 1) => Number(Number(n).toFixed(d));
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmtTime = (ts) => {
    const d = ts && ts.toDate ? ts.toDate() : ts ? new Date(ts) : null;
    return d && !isNaN(d) ? d.toLocaleString("en-IN") : "";
  };
  const withEmpty = (rows, message) => (rows.length > 1 ? rows : [...rows, [message]]);

  // ---------- Auth screen ----------
  const AUTH_ERRORS = {
    "auth/invalid-email": "That email address doesn't look right.",
    "auth/invalid-credential": "Email or password is incorrect.",
    "auth/wrong-password": "Email or password is incorrect.",
    "auth/user-not-found": "Email or password is incorrect.",
    "auth/email-already-in-use": "An account already exists for that email. Try signing in.",
    "auth/weak-password": "Use at least 6 characters for your password.",
    "auth/too-many-requests": "Too many attempts. Wait a few minutes and try again.",
    "auth/network-request-failed": "Network error. Check your connection and try again."
  };
  const friendly = (err) => AUTH_ERRORS[err && err.code] || (err && err.message) || "Something went wrong. Try again.";

  function setAuthMessage(text, isError = true) {
    const el = $("auth-message");
    el.textContent = text;
    el.classList.toggle("ok", !isError);
  }
  function setAuthBusy(busy) {
    $("auth-submit").disabled = busy;
  }
  function setAuthMode(mode) {
    authMode = mode;
    const signup = mode === "signup";
    $("auth-title").textContent = signup ? "Create your fleet account" : "Sign in to your fleet";
    $("auth-submit").textContent = signup ? "Create account" : "Sign in";
    $("auth-toggle").textContent = signup ? "I already have an account" : "Create an account";
    $("auth-password").autocomplete = signup ? "new-password" : "current-password";
    setAuthMessage("");
  }
  async function onAuthSubmit(event) {
    event.preventDefault();
    if (!auth) { setAuthMessage("Add your Firebase keys to firebase-config.js to sign in. Use demo mode for now."); return; }
    const email = $("auth-email").value.trim();
    const password = $("auth-password").value;
    if (!email || !password) { setAuthMessage("Enter your email and password."); return; }
    setAuthBusy(true);
    setAuthMessage("");
    try {
      if (authMode === "signup") await auth.createUserWithEmailAndPassword(email, password);
      else await auth.signInWithEmailAndPassword(email, password);
      $("auth-password").value = "";
    } catch (err) {
      setAuthMessage(friendly(err));
    } finally {
      setAuthBusy(false);
    }
  }
  async function onForgotPassword() {
    if (!auth) { setAuthMessage("Add your Firebase keys to firebase-config.js to reset passwords."); return; }
    const email = $("auth-email").value.trim();
    if (!email) { setAuthMessage("Enter your email first, then tap Forgot password."); return; }
    try {
      await auth.sendPasswordResetEmail(email);
      setAuthMessage("Password reset email sent. Check your inbox.", false);
    } catch (err) {
      setAuthMessage(friendly(err));
    }
  }
  async function onSignOut() {
    stopLocation(true);
    try {
      await auth.signOut();
      app.toast("Signed out.");
    } catch (err) {
      app.toast("Could not sign out: " + friendly(err));
    }
  }

  // ---------- Profile and session ----------
  const displayNameFor = (u) => u.displayName || (u.email || "Fleet user").split("@")[0];
  const initialsOf = (name) =>
    name.split(/[\s._-]+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join("") || "?";

  function showProfile(name, email) {
    $("profile-name").textContent = name;
    $("profile-email").textContent = email;
    $("profile-avatar").textContent = initialsOf(name);
  }

  function onAuthChanged(u) {
    user = u || null;
    if (user) {
      const name = displayNameFor(user);
      showProfile(name, user.email || "Signed in");
      $("greeting-name").textContent = name.split(/[\s._-]+/)[0] + ".";
      $("auth-overlay").hidden = true;
      $("auth-password").value = "";
      $("signout-btn").hidden = false;
      $("profile-dots").hidden = true;
      userRef().set({ email: user.email || "", lastSignInAt: serverTime() }, { merge: true }).catch(() => {});
      subscribeVehicles();
      app.addActivity("Signed in", (user.email || "Account") + " · cloud sync on", "purple-bg", "◷");
    } else {
      stopLocation(false);
      unsubscribeFromVehicles();
      showProfile("Dhivakar Fleet", "Demo workspace");
      $("greeting-name").textContent = "Dhivakar.";
      $("signout-btn").hidden = true;
      $("profile-dots").hidden = false;
      if (configured) $("auth-overlay").hidden = false;
    }
  }

  // ---------- Live visitor location ----------
  function setLocationButton(on) {
    const btn = $("location-share-btn");
    btn.setAttribute("aria-pressed", String(on));
    btn.textContent = on ? "◉ Sharing location" : "◉ Share my location";
  }
  function toggleLocation() {
    if (watchId !== null) stopLocation(true);
    else startLocation();
  }
  function startLocation() {
    if (!configured || !user) { app.toast("Sign in to share your location."); return; }
    if (!navigator.geolocation) { app.toast("This browser can't share location."); return; }
    lastWriteAt = 0;
    watchId = navigator.geolocation.watchPosition(onPosition, onLocationError,
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 20000 });
    setLocationButton(true);
    app.toast("Location sharing on. Your marker appears on the map.");
  }
  function onPosition(pos) {
    const { latitude: lat, longitude: lng, accuracy } = pos.coords;
    const map = app.map();
    if (map) {
      if (!visitorMarker) {
        visitorMarker = L.circleMarker([lat, lng], { radius: 8, color: "#75baff", fillColor: "#75baff", fillOpacity: 0.35, weight: 2 })
          .addTo(map).bindPopup("<b>Your location</b><br>Shared while sharing is on");
      } else {
        visitorMarker.setLatLng([lat, lng]);
      }
    }
    const now = Date.now();
    if (now - lastWriteAt < LOCATION_WRITE_MS) return;
    lastWriteAt = now;
    userRef().collection("visitor").doc("current")
      .set({ lat, lng, accuracy: Math.round(accuracy), sharing: true, updatedAt: serverTime() }, { merge: true })
      .catch((err) => app.toast("Could not save location: " + (err.code || err.message)));
  }
  function onLocationError(err) {
    const reasons = { 1: "Location permission was denied.", 2: "Your location is unavailable right now.", 3: "Location request timed out." };
    app.toast(reasons[err.code] || "Location error.");
    if (err.code === 1) stopLocation(true);
  }
  function stopLocation(writeStop) {
    if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; }
    if (visitorMarker) { visitorMarker.remove(); visitorMarker = null; }
    setLocationButton(false);
    if (writeStop && user) {
      userRef().collection("visitor").doc("current")
        .set({ sharing: false, updatedAt: serverTime() }, { merge: true }).catch(() => {});
    }
  }

  // ---------- Vehicle GPS (live Firestore feed) ----------
  // Devices write to users/{uid}/vehicles/{vehicleId} with lat, lng, battery, status and name.
  function subscribeVehicles() {
    unsubscribeFromVehicles();
    const map = app.map();
    if (!user || !map) return;
    vehicleLayer = L.layerGroup().addTo(map);
    unsubscribeVehicles = userRef().collection("vehicles").onSnapshot((snap) => {
      vehicleLayer.clearLayers();
      snap.forEach((doc) => {
        const v = doc.data();
        if (typeof v.lat !== "number" || typeof v.lng !== "number") return;
        const popup = `<b>${esc(doc.id)} · ${esc(v.name || "Vehicle")}</b><br>Battery: ${esc(v.battery ?? "—")}%<br>Status: ${esc(v.status || "Unknown")}`;
        L.marker([v.lat, v.lng], { icon: app.makeIcon("ϟ", "#75baff") }).bindPopup(popup).addTo(vehicleLayer);
      });
    }, (err) => app.toast("Vehicle feed error: " + (err.code || err.message)));
  }
  function unsubscribeFromVehicles() {
    if (unsubscribeVehicles) { unsubscribeVehicles(); unsubscribeVehicles = null; }
    if (vehicleLayer) { vehicleLayer.remove(); vehicleLayer = null; }
  }

  // ---------- Trip records ----------
  document.addEventListener("ecofleet:trip-complete", async (event) => {
    const trip = event.detail || {};
    if (!user) { app.toast("Trip finished. Sign in to save it to your account."); return; }
    try {
      await userRef().collection("trips").add({ ...trip, completedAt: serverTime() });
      app.toast("Trip record saved to your account.");
    } catch (err) {
      app.toast("Could not save trip: " + (err.code || err.message));
    }
  });

  // ---------- Excel export ----------
  function sheetFrom(rows) {
    const ws = XLSX.utils.aoa_to_sheet(rows);
    const widths = [];
    rows.forEach((row) => row.forEach((cell, i) => {
      widths[i] = Math.max(widths[i] || 10, String(cell ?? "").length + 2);
    }));
    ws["!cols"] = widths.map((w) => ({ wch: Math.min(w, 48) }));
    return ws;
  }

  async function exportWorkbook() {
    if (typeof XLSX === "undefined") {
      app.toast("Excel library didn't load. Check your connection and try again.");
      return;
    }
    const snap = app.getDashboardSnapshot();
    const now = new Date();
    const exportedAt = now.toLocaleString("en-IN");

    let account = [["Field", "Value"], ["Name", "Demo workspace"], ["Email", "Not signed in"], ["User ID", "—"], ["Mode", "Demo (sign in to export your account data)"]];
    let visitorRows = [["Latitude", "Longitude", "Accuracy (m)", "Sharing", "Last updated"], ["No visitor location recorded"]];
    let tripRows = [["Trip ID", "Completed", "Vehicle", "Distance (km)", "Energy (kWh)", "CO₂ avoided (kg)", "Duration (min)"]];
    let cloudVehicleRows = [];

    if (user && db) {
      try {
        const [visitorDoc, vehicleSnap, tripSnap] = await Promise.all([
          userRef().collection("visitor").doc("current").get(),
          userRef().collection("vehicles").get(),
          userRef().collection("trips").orderBy("completedAt", "desc").limit(500).get()
        ]);
        account = [["Field", "Value"], ["Name", displayNameFor(user)], ["Email", user.email || ""], ["User ID", user.uid], ["Mode", "Signed in"]];
        if (visitorDoc.exists) {
          const v = visitorDoc.data();
          visitorRows = [["Latitude", "Longitude", "Accuracy (m)", "Sharing", "Last updated"],
            [v.lat, v.lng, v.accuracy ?? "", v.sharing ? "Yes" : "No", fmtTime(v.updatedAt)]];
        }
        cloudVehicleRows = vehicleSnap.docs.map((d) => {
          const v = d.data();
          return [d.id, v.name || "", v.lat, v.lng, v.battery ?? "", v.status || "", fmtTime(v.updatedAt), "Cloud"];
        });
        tripRows = [...tripRows, ...tripSnap.docs.map((d) => {
          const t = d.data();
          return [d.id, fmtTime(t.completedAt), t.vehicleId || "", t.distanceKm ?? "", t.energyKwh ?? "", t.carbonKg ?? "", t.durationMin ?? ""];
        })];
      } catch (err) {
        app.toast("Could not read cloud data: " + (err.code || err.message));
        return;
      }
    }
    account.push(["Exported at", exportedAt]);

    const vehicleRows = [["Vehicle ID", "Name", "Latitude", "Longitude", "Battery (%)", "Status", "Last updated", "Source"],
      ...(cloudVehicleRows.length ? cloudVehicleRows
        : snap.vehicles.map((v) => [v.id, v.name, v.lat, v.lng, v.battery, v.status, "", "Simulated (demo)"]))];

    const r = snap.route;
    const dashboardRows = [["Metric", "Value"],
      ["CO₂ emissions avoided (KPI, kg)", snap.metrics.co2AvoidedKg],
      ["Fuel cost saved (KPI)", snap.metrics.fuelCostSaved],
      ["Fleet efficiency (KPI, %)", snap.metrics.fleetEfficiencyPct],
      ["Active vehicles", snap.metrics.activeVehicles],
      ["Optimized route distance (km)", round(r.distanceKm)],
      ["Estimated travel time", r.travelTime],
      ["Energy use (kWh)", round(r.energyKwh)],
      ["CO₂ avoided on route (kg)", round(r.carbonKg)],
      ["Distance vs diesel baseline (%)", round(r.distanceVsDieselPct)],
      ["Payload (kg)", r.settings.payloadKg],
      ["Elevation impact (%)", r.settings.elevationPct],
      ["Traffic avoidance (%)", r.settings.trafficPct],
      ["EV preference (%)", r.settings.evPreferencePct]];

    const days = snap.analytics.days;
    const analyticsRows = [["Day", "Date", "Diesel baseline (kg)", "CO₂ saved (kg)"],
      ...snap.analytics.dailyBaselineKg.map((v, i) => {
        const d = new Date(now);
        d.setDate(now.getDate() - (days - 1 - i));
        return [`Day ${i + 1}`, d.toLocaleDateString("en-IN"), round(v), round(v * snap.analytics.savingsRatio)];
      })];

    const activityRows = [["Event", "Details", "Time"], ...snap.activity.map((a) => [a.title, a.detail, a.time])];

    const wb = XLSX.utils.book_new();
    const add = (name, rows) => XLSX.utils.book_append_sheet(wb, sheetFrom(rows), name);
    add("Account", account);
    add("Visitor location", visitorRows);
    add("Vehicle GPS", vehicleRows);
    add("Trips", withEmpty(tripRows, "No trip records yet"));
    add("Analytics", analyticsRows);
    add("Dashboard", dashboardRows);
    add("Network activity", activityRows);

    XLSX.writeFile(wb, `ecofleet-report-${now.toISOString().slice(0, 10)}.xlsx`);
    app.addActivity("Report exported", "Excel workbook · " + exportedAt, "amber-bg", "⇩");
    app.toast("Excel report downloaded.");
  }

  // ---------- Setup ----------
  function init() {
    if (!app) {
      console.error("EcoFleet: app.js must load before firebase-service.js");
      return;
    }
    app.exportWorkbook = exportWorkbook;

    $("auth-form").addEventListener("submit", onAuthSubmit);
    $("auth-toggle").addEventListener("click", () => setAuthMode(authMode === "signin" ? "signup" : "signin"));
    $("auth-reset").addEventListener("click", onForgotPassword);
    $("signout-btn").addEventListener("click", onSignOut);
    $("location-share-btn").addEventListener("click", toggleLocation);

    if (!configured) {
      $("config-banner").hidden = false;
      $("auth-overlay").hidden = false;
      $("demo-continue").hidden = false;
      $("demo-continue").addEventListener("click", () => { $("auth-overlay").hidden = true; });
      return;
    }
    firebase.initializeApp(cfg);
    auth = firebase.auth();
    db = firebase.firestore();
    auth.onAuthStateChanged(onAuthChanged);
  }

  init();
})();
